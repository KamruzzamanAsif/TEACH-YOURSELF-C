#include<stdio.h>

int main(void)
{
    int i;
    long double ld;
    ld = 10.0;
    i = ld;

    printf("%d",i);

    return 0;
}
