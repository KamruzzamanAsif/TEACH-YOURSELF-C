#include<stdio.h>

int main(void)
{
    int i;
    float f;

    i = 10;
    f = 23.25;

    printf("%f",i*f);

    return 0;
}
