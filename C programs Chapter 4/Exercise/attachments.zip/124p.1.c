#include<stdio.h>

int main(void)
{
int i = -1;

printf("i is initialized to  %d",i);

return 0;
}
