#include<stdio.h>

int main(void)
{
    float f;

    f = 10/3;
    printf("%f",f);

    return 0;
}
