#include<stdio.h>
int main(void)
{
	unsigned u;
	long l;
	short s;

    printf(" Enter an unsingned:  ");
    scanf("%u",&u);

    printf(" Enter a long:  ");
    scanf("%ld",&l);

    printf(" Enter a short:  ");
    scanf("%hd",&s);

 printf("%u %ld %hd",u,l,s);
return 0;
}
