#include<stdio.h>
void f1(void);
void f2(void);

int main(void)
{
f1();

return 0;
}

void f1(void)
{
    int count;

    for(count=0;count<10;count++)
    f2();
}

void f2(void)
{
    int count;

    for(count=0;count<10;count++)
    printf("%d",count);
}
