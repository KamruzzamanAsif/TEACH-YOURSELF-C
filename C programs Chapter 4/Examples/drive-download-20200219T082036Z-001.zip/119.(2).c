#include<stdio.h>

float soundspeed(float a, float b);

int main()
{
   float s;

   s=soundspeed(a,b);

   printf("your time is %f second ",s);

return 0;
}

float soundspeed(float a, float b)
{
    printf("Input distence in feet");
    scanf("%F",&a);

    b = a/1129;

return b;
}
