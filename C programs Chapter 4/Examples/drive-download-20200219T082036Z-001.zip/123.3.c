#include<stdio.h>

int main()
{
    printf("%s %s %s","I","like","c");

    return 0;
}
