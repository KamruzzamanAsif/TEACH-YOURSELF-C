#include<stdio.h>

int main()
{
    long int a;

    printf("Input a long integer number");
    scanf("%ld",&a);

    printf("Your input number is %ld",a);

return 0;
}
