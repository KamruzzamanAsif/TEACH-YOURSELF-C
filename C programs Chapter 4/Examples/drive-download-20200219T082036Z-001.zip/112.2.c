#include<stdio.h>

int main()
{
unsigned long int a,d;
printf("Input a distence");
scanf("%lu",&a);

d = a/186000;

printf("time is %d",d);
return 0;
}
