#include<stdio.h>

int a = 1,b = 1,c = a;

int main()
{
    printf("%d %d %d",a,b,c);

return 0;
}
