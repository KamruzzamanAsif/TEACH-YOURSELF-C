#include<stdio.h>

int main()
{
    int i;

    for(i=100;i>0;i--)
        printf("\t%d",i);

return 0;
}
